
module.exports = { 
    HOST: "185.220.172.6",
    USER: "u157428p236054_admin", 
    PASSWORD: "#Sneakers2640!!!", 
    DB: "u157428p236054_g_app", 
    dialect: "mysql",
    port: 3306,
    pool: { 
      max: 5, 
      min: 0, 
      acquire: 30000, 
      idle: 10000 
    } 
  }; 